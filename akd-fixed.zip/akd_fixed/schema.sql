-- ============================================================
-- Ledger schema — v2
-- Paste this whole file into Supabase → SQL Editor → New query → Run.
-- Safe whether this is a brand new project OR you already ran the
-- old schema.sql before (it upgrades in place, nothing is deleted
-- except the old single "note" column, whose text is copied over
-- into income_note first).
-- ============================================================

create table if not exists entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id),
  entry_date date not null default current_date,
  income numeric not null default 0,
  withdrawal numeric not null default 0,
  income_note text,
  withdrawal_note text,
  created_at timestamptz not null default now()
);

-- ---- upgrade path from the old (v1) schema ----

-- v1 only allowed one row per user per day; v2 allows several entries
-- a day (so saving clears the form for the next one instead of
-- overwriting today's row) — drop that old constraint if present
drop index if exists entries_user_date_unique;

alter table entries add column if not exists income_note text;
alter table entries add column if not exists withdrawal_note text;

do $$
begin
  if exists (
    select 1 from information_schema.columns
    where table_name = 'entries' and column_name = 'note'
  ) then
    update entries set income_note = coalesce(income_note, note) where note is not null;
    alter table entries drop column note;
  end if;
end $$;

-- speeds up the date-range queries the report function runs
create index if not exists entries_user_date_idx on entries (user_id, entry_date);

-- ---- row level security (idempotent — safe to re-run) ----
alter table entries enable row level security;

drop policy if exists "Users can view their own entries" on entries;
create policy "Users can view their own entries"
  on entries for select using (auth.uid() = user_id);

drop policy if exists "Users can insert their own entries" on entries;
create policy "Users can insert their own entries"
  on entries for insert with check (auth.uid() = user_id);

drop policy if exists "Users can update their own entries" on entries;
create policy "Users can update their own entries"
  on entries for update using (auth.uid() = user_id);

drop policy if exists "Users can delete their own entries" on entries;
create policy "Users can delete their own entries"
  on entries for delete using (auth.uid() = user_id);


-- ============================================================
-- Nightly Telegram reminder at 9pm (Amharic message)
-- ------------------------------------------------------------
-- Only run the block below AFTER you've deployed the
-- `daily-reminder` edge function and set its secrets (see
-- SETUP.md step 3). Replace the two placeholders first:
--   YOUR-PROJECT-REF   → the ref in your Supabase project URL
--                         (https://<ref>.supabase.co)
--   YOUR-CRON-SECRET   → the same value you used for
--                         `supabase secrets set CRON_SECRET=...`
-- ============================================================

create extension if not exists pg_cron;
create extension if not exists pg_net;

do $$
begin
  if exists (select 1 from cron.job where jobname = 'nightly-income-reminder') then
    perform cron.unschedule('nightly-income-reminder');
  end if;
end $$;

select cron.schedule(
  'nightly-income-reminder',
  '0 18 * * *',  -- 18:00 UTC = 21:00 (9 PM) Addis Ababa time — Ethiopia has no DST
  $$
  select net.http_post(
    url := 'https://YOUR-PROJECT-REF.functions.supabase.co/daily-reminder',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-cron-secret', 'YOUR-CRON-SECRET'
    ),
    body := '{}'::jsonb
  );
  $$
);
