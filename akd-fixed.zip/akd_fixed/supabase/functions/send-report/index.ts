// supabase/functions/send-report/index.ts
//
// Called by the website when you tap "Send report to Telegram" on the
// Report tab. It:
//   1. checks who you are from your login session (so you only ever
//      get your own entries — Row Level Security enforces this too),
//   2. pulls every entry between the two dates you picked,
//   3. builds a PDF listing each day's income/withdrawal and the
//      comment you wrote for it, with totals at the top,
//   4. sends that PDF straight to your Telegram.
//
// Secrets needed (see SETUP.md):
//   TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
// SUPABASE_URL and SUPABASE_ANON_KEY are injected automatically by
// the Supabase Edge Runtime, you don't need to set those yourself.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { PDFDocument, StandardFonts, rgb } from "https://esm.sh/pdf-lib@1.17.1";
import fontkit from "https://esm.sh/@pdf-lib/fontkit@1.1.1";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const TELEGRAM_BOT_TOKEN = Deno.env.get("TELEGRAM_BOT_TOKEN")!;
const TELEGRAM_CHAT_ID = Deno.env.get("TELEGRAM_CHAT_ID")!;

// A Unicode font so Amharic comments render correctly in the PDF.
// If it can't be fetched (e.g. offline), the report still sends —
// non-Latin comments will just be skipped in the PDF text in that
// fallback case.
const ETHIOPIC_FONT_URL =
  "https://raw.githubusercontent.com/googlefonts/noto-fonts/main/hinted/ttf/NotoSansEthiopic/NotoSansEthiopic-Regular.ttf";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function fmt(n: number) {
  return Number(n || 0).toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Use POST" }, 405);

  try {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace(/^Bearer\s+/i, "");
    if (!token) return json({ error: "Missing auth token" }, 401);

    const body = await req.json().catch(() => ({}));
    const { from, to } = body as { from?: string; to?: string };
    if (!from || !to) return json({ error: "from and to dates are required" }, 400);

    // Use the caller's own JWT so Row Level Security naturally limits
    // this to their entries only — no service_role key needed here.
    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: `Bearer ${token}` } },
    });

    const { data: userData, error: userErr } = await supabase.auth.getUser();
    if (userErr || !userData?.user) return json({ error: "Invalid session, please sign in again" }, 401);

    const { data: entries, error } = await supabase
      .from("entries")
      .select("*")
      .gte("entry_date", from)
      .lte("entry_date", to)
      .order("entry_date", { ascending: true })
      .order("created_at", { ascending: true });

    if (error) return json({ error: error.message }, 500);

    const pdfBytes = await buildReportPdf(from, to, entries || []);
    const tgResult = await sendTelegramDocument(pdfBytes, from, to, entries || []);

    if (!tgResult.ok) {
      return json({ error: "Telegram error: " + (tgResult.description || "unknown") }, 502);
    }

    return json({ ok: true });
  } catch (e) {
    return json({ error: String(e instanceof Error ? e.message : e) }, 500);
  }
});

// ---------- PDF building ----------

async function buildReportPdf(
  from: string,
  to: string,
  entries: Array<{
    entry_date: string;
    income: number;
    withdrawal: number;
    income_note: string | null;
    withdrawal_note: string | null;
  }>,
) {
  const pdfDoc = await PDFDocument.create();
  pdfDoc.registerFontkit(fontkit);

  let regularFont;
  let boldFont;
  try {
    const fontBytes = await fetch(ETHIOPIC_FONT_URL).then((r) => {
      if (!r.ok) throw new Error("font fetch failed");
      return r.arrayBuffer();
    });
    regularFont = await pdfDoc.embedFont(fontBytes, { subset: true });
    boldFont = regularFont; // Noto Sans Ethiopic regular doubles as bold here
  } catch {
    regularFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
    boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  }

  const pageWidth = 595.28; // A4
  const pageHeight = 841.89;
  const margin = 44;
  const contentWidth = pageWidth - margin * 2;

  let page = pdfDoc.addPage([pageWidth, pageHeight]);
  let y = pageHeight - margin;

  const ensureSpace = (needed: number) => {
    if (y - needed < margin) {
      page = pdfDoc.addPage([pageWidth, pageHeight]);
      y = pageHeight - margin;
    }
  };

  const wrapText = (text: string, font: typeof regularFont, size: number, maxWidth: number) => {
    const words = text.split(/\s+/).filter(Boolean);
    const lines: string[] = [];
    let line = "";
    for (const word of words) {
      const test = line ? line + " " + word : word;
      if (font.widthOfTextAtSize(test, size) > maxWidth && line) {
        lines.push(line);
        line = word;
      } else {
        line = test;
      }
    }
    if (line) lines.push(line);
    return lines;
  };

  const drawLine = (
    text: string,
    opts: { size?: number; bold?: boolean; color?: ReturnType<typeof rgb>; indent?: number } = {},
  ) => {
    const size = opts.size ?? 11;
    const font = opts.bold ? boldFont : regularFont;
    const indent = opts.indent ?? 0;
    const lines = wrapText(text, font, size, contentWidth - indent);
    for (const l of lines) {
      ensureSpace(size + 6);
      page.drawText(l, {
        x: margin + indent,
        y,
        size,
        font,
        color: opts.color ?? rgb(0.08, 0.1, 0.1),
      });
      y -= size + 6;
    }
  };

  const totalIncome = entries.reduce((s, e) => s + Number(e.income || 0), 0);
  const totalWithdrawal = entries.reduce((s, e) => s + Number(e.withdrawal || 0), 0);
  const net = totalIncome - totalWithdrawal;

  drawLine("Income & Withdrawal Report", { size: 20, bold: true });
  y -= 4;
  drawLine(`Period: ${from} -> ${to}`, { size: 11, color: rgb(0.4, 0.42, 0.4) });
  y -= 10;

  drawLine(`Total income: ${fmt(totalIncome)}`, { size: 12, bold: true, color: rgb(0.05, 0.5, 0.2) });
  drawLine(`Total withdrawal: ${fmt(totalWithdrawal)}`, { size: 12, bold: true, color: rgb(0.7, 0.15, 0.15) });
  drawLine(`Net: ${net >= 0 ? "+" : ""}${fmt(net)}`, { size: 12, bold: true });
  y -= 14;

  if (entries.length === 0) {
    drawLine("No entries in this period.", { size: 11, color: rgb(0.4, 0.42, 0.4) });
  }

  let lastDate = "";
  for (const e of entries) {
    if (e.entry_date !== lastDate) {
      y -= 6;
      ensureSpace(24);
      drawLine(e.entry_date, { size: 13, bold: true });
      lastDate = e.entry_date;
    }

    if (Number(e.income) > 0) {
      const noteText = e.income_note ? `you got income of ${fmt(e.income)} for ${e.income_note}` : `income of ${fmt(e.income)}`;
      drawLine(`+ ${noteText}`, { size: 10.5, indent: 12, color: rgb(0.05, 0.5, 0.2) });
    }
    if (Number(e.withdrawal) > 0) {
      const noteText = e.withdrawal_note
        ? `you withdrew ${fmt(e.withdrawal)} for ${e.withdrawal_note}`
        : `withdrawal of ${fmt(e.withdrawal)}`;
      drawLine(`- ${noteText}`, { size: 10.5, indent: 12, color: rgb(0.7, 0.15, 0.15) });
    }
  }

  return await pdfDoc.save();
}

// ---------- Telegram delivery ----------

async function sendTelegramDocument(
  pdfBytes: Uint8Array,
  from: string,
  to: string,
  entries: Array<{ income: number; withdrawal: number }>,
) {
  const totalIncome = entries.reduce((s, e) => s + Number(e.income || 0), 0);
  const totalWithdrawal = entries.reduce((s, e) => s + Number(e.withdrawal || 0), 0);
  const net = totalIncome - totalWithdrawal;

  const caption =
    `📊 Report ${from} -> ${to}\n` +
    `Entries: ${entries.length}\n` +
    `Total income: ${fmt(totalIncome)}\n` +
    `Total withdrawal: ${fmt(totalWithdrawal)}\n` +
    `Net: ${net >= 0 ? "+" : ""}${fmt(net)}`;

  const form = new FormData();
  form.append("chat_id", TELEGRAM_CHAT_ID);
  form.append("caption", caption.slice(0, 1024));
  form.append("document", new Blob([pdfBytes], { type: "application/pdf" }), `report_${from}_to_${to}.pdf`);

  const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument`, {
    method: "POST",
    body: form,
  });

  return await res.json();
}
