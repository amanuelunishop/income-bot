// supabase/functions/daily-reminder/index.ts
//
// Sends a nightly Telegram reminder (in Amharic) telling you to log
// today's income. Meant to be triggered once a day by pg_cron (see
// schema.sql) — not by the website itself.
//
// Secrets needed (set once with the Supabase CLI, see SETUP.md):
//   TELEGRAM_BOT_TOKEN
//   TELEGRAM_CHAT_ID
//   CRON_SECRET        (any random string you make up — this is
//                        what proves the request really came from
//                        your own pg_cron job and not a stranger)

const TELEGRAM_BOT_TOKEN = Deno.env.get("TELEGRAM_BOT_TOKEN")!;
const TELEGRAM_CHAT_ID = Deno.env.get("TELEGRAM_CHAT_ID")!;
const CRON_SECRET = Deno.env.get("CRON_SECRET")!;

const MESSAGE =
  "🔔 የምሽት ማስታወሻ\n\n" +
  "እባክዎ የዛሬውን ገቢ እና ወጪ በድረ-ገጹ ላይ ያስገቡ።";

Deno.serve(async (req: Request) => {
  if (req.headers.get("x-cron-secret") !== CRON_SECRET) {
    return new Response("unauthorized", { status: 401 });
  }

  const tgRes = await fetch(
    `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        text: MESSAGE,
      }),
    },
  );

  const data = await tgRes.json();

  return new Response(JSON.stringify(data), {
    status: tgRes.ok ? 200 : 500,
    headers: { "Content-Type": "application/json" },
  });
});
