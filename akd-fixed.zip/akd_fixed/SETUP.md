# Setup — what changed and how to turn it on

Three things were fixed:

1. **9pm Amharic reminder** — a message goes to your Telegram every night
   reminding you to log today's income/withdrawal.
2. **Save clears the form** — each save now creates a new entry instead of
   overwriting "today's row", so the boxes go blank right after saving and
   are ready for the next one. The weekly/monthly totals that used to sit
   on the page all the time are gone — instead there's a **Report** tab
   where you pick a day range and it gets sent to your Telegram.
3. **Comments on income/withdrawal** — each entry can carry its own comment
   ("shop sales", "supplier payment", etc). The report is a **PDF** and
   spells each one out, e.g. *"you withdrew 500.00 for supplier payment"*.

Everything below the website itself (the reminder + the report) runs as two
small **Supabase Edge Functions**, so you still don't need your own server —
just the same free Supabase project you already have. Your Telegram bot
token lives only in Supabase's function secrets, never in the website code,
so it's never visible to anyone opening the page.

---

## Step 1 — Update the database

Supabase → your project → **SQL Editor** → New query → paste the whole
contents of `schema.sql` → **Run**.

(It's safe to run even though you already ran the old `schema.sql` — it
upgrades the table in place. Skip the `pg_cron` block at the bottom for now,
come back to it in Step 4.)

## Step 2 — Install the Supabase CLI and link your project

```bash
npm install -g supabase
supabase login
cd path/to/this/folder      # the folder that contains index.html AND supabase/
supabase link --project-ref YOUR-PROJECT-REF
```

Your project ref is the random string in your project URL:
`https://YOUR-PROJECT-REF.supabase.co`.

## Step 3 — Set the secrets and deploy the two functions

```bash
supabase secrets set \
  TELEGRAM_BOT_TOKEN=8795828165:AAFuZ_3G2eZNmlZ-BHaA8L81ENC578kXZo8 \
  TELEGRAM_CHAT_ID=465740704 \
  CRON_SECRET=pick-any-long-random-string-here

supabase functions deploy daily-reminder --no-verify-jwt
supabase functions deploy send-report
```

- `daily-reminder` uses `--no-verify-jwt` because pg_cron calls it directly
  (it checks the `x-cron-secret` header itself instead).
- `send-report` is left with JWT verification **on** — only your own logged
  in session can trigger it, and it only ever returns your own entries.

You can test the reminder manually right away:

```bash
curl -X POST "https://YOUR-PROJECT-REF.functions.supabase.co/daily-reminder" \
  -H "x-cron-secret: pick-any-long-random-string-here"
```

You should get the Amharic reminder on Telegram within a couple of seconds.

## Step 4 — Schedule the 9pm reminder

Back in Supabase → **SQL Editor**, run just the last block of `schema.sql`
(the one starting with `create extension if not exists pg_cron;`), after
replacing:

- `YOUR-PROJECT-REF` → your project ref
- `YOUR-CRON-SECRET` → the same string you used for `CRON_SECRET` above

It's scheduled for `18:00 UTC`, which is `21:00 / 9pm` in Addis Ababa
(Ethiopia doesn't observe daylight saving, so this stays correct year-round).

> If your Supabase plan doesn't have `pg_cron`/`pg_net` available, use a free
> service like cron-job.org instead: point it at
> `https://YOUR-PROJECT-REF.functions.supabase.co/daily-reminder` once a day
> at 18:00 UTC, with header `x-cron-secret: YOUR-CRON-SECRET`.

## Step 5 — Re-upload the site files

Upload the updated `index.html`, `style.css`, `app.js`, `config.js` to
wherever you're hosting (Cloudflare Pages / Netlify) — same as the first
time, just drag-and-drop the folder again. `config.js` is unchanged, so if
you like you can skip re-uploading it.

## Using it day to day

- **Today tab**: type an income and/or withdrawal, add a short comment for
  each if you want, tap **Save entry** — the boxes clear immediately so you
  can log the next one straight away.
- **Report tab**: pick a from/to date (defaults to the 1st of this month
  through today), tap **Send report to Telegram** — a PDF lands in your
  Telegram within a few seconds, listing every entry with its comment and
  the totals at the top.
- Every night at 9pm you'll get the Amharic reminder automatically.

## If something doesn't send

- Report tab says "Failed: ..." → open the browser console (F12) for the
  full error, and check `supabase functions logs send-report` from the CLI.
- No reminder at 9pm → run the manual `curl` test in Step 3 first to confirm
  the function itself works, then double check the `cron.job` row exists:
  `select * from cron.job;` in the SQL Editor.
